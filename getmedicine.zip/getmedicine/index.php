<html>
	<head>
		<title>Social Medicine</title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="css/main.css">

		<link href="https://fonts.googleapis.com/css?family=Roboto+Condensed" rel="stylesheet">
	</head>
	<body>
		<div class="menu">
			<div id="logo-div">
				<img src="images/search.png">
			</div>

			<div>
				<ul>
					<li><a href="#">Teste 1</a></li>
					<li><a href="#">Teste 2</a></li>

				</ul>	
			</div>
			<div id="find-medicine-div">
				<input type="text" placeholder="Pesquisar: remédio ou sintomas.">
				<button><img src="images/search.png"></button>
			</div>
			<div id="user-info">
				<img src="images/teste.jpg">
				Helio Nakayama
			</div>


		</div>

		<div class="main-div">
			<div class="friend-list">

			</div><!--
			--><div class="map">
				<div class="map-area">
					
				<div>
			</div>
		</div>
	</body>
</html>